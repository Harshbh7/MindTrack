import type { NextApiRequest, NextApiResponse } from 'next';

type ResponseData = {
    suggestion: string;
};

export default function handler(
    req: NextApiRequest,
    res: NextApiResponse<ResponseData>
) {
    if (req.method !== 'POST') {
        return res.status(405).json({ suggestion: 'Method not allowed' });
    }

    const { code, language } = req.body;

    // Mock AI Logic (In production, call OpenAI API here)
    let suggestion = "Code looks good! No obvious errors.";

    if (!code || code.trim().length === 0) {
        suggestion = "Please write some code first so I can review it!";
    } else if (code.includes("console.log")) {
        suggestion = "💡 Tip: Avoid using 'console.log' in production code. Consider using a proper logging library.";
    } else if (code.includes("eval(")) {
        suggestion = "⚠️ Security Warning: 'eval()' is dangerous and can execute malicious code. Avoid it!";
    } else if (code.includes("var ")) {
        suggestion = "💡 Modern JS Tip: Use 'const' or 'let' instead of 'var' for better scope management.";
    } else if (language === "python" && !code.includes("def ")) {
        suggestion = "💡 Python Tip: Consider wrapping your logic in functions for better modularity.";
    } else if (language === "cpp" && code.includes("using namespace std;")) {
        suggestion = "💡 C++ Best Practice: Avoid 'using namespace std;' in header files to prevent name conflicts.";
    }

    // Simulate network delay
    setTimeout(() => {
        res.status(200).json({ suggestion });
    }, 1500);
}
