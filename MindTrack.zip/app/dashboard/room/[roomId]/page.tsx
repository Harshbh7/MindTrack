"use client";

import { use, useState } from "react";
import Chat from "@/components/Chat";
import ParticipantList from "@/components/ParticipantList";
import FocusTimer from "@/components/FocusTimer";
import Whiteboard from "@/components/Whiteboard";
import VideoCall from "@/components/VideoCall";
import { useAuth } from "@/context/AuthContext";
import { Video, PenTool } from "lucide-react";

export default function RoomPage({ params }: { params: Promise<{ roomId: string }> }) {
    const { roomId } = use(params);
    const { user } = useAuth();
    const [activeTab, setActiveTab] = useState<"video" | "board">("video");

    return (
        <div className="flex h-[calc(100vh-6rem)] gap-4">
            {/* Main Content Area */}
            <div className="flex-1 flex flex-col space-y-4 overflow-hidden">
                {/* Mode Toggles */}
                <div className="flex gap-2">
                    <button
                        onClick={() => setActiveTab("video")}
                        className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors ${activeTab === "video"
                            ? "bg-blue-600 text-white"
                            : "bg-gray-800 text-gray-400 hover:bg-gray-700 hover:text-white"
                            }`}
                    >
                        <Video className="w-4 h-4" />
                        Focus & Video
                    </button>
                    <button
                        onClick={() => setActiveTab("board")}
                        className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors ${activeTab === "board"
                            ? "bg-purple-600 text-white"
                            : "bg-gray-800 text-gray-400 hover:bg-gray-700 hover:text-white"
                            }`}
                    >
                        <PenTool className="w-4 h-4" />
                        Whiteboard
                    </button>
                    <div className="ml-auto bg-gray-800 px-4 py-2 rounded-lg text-sm text-gray-400 border border-gray-700">
                        Room: <span className="font-mono text-white ml-2">{roomId}</span>
                    </div>
                </div>

                {/* Content View */}
                <div className="flex-1 bg-gray-900 border border-gray-800 rounded-xl overflow-hidden relative">
                    {activeTab === "video" ? (
                        <div className="p-6 h-full overflow-y-auto flex flex-col items-center gap-6">
                            <FocusTimer />

                            <div className="w-full max-w-4xl">
                                <h3 className="text-lg font-semibold text-gray-400 mb-4 flex items-center gap-2">
                                    <Video className="w-5 h-5" /> Video Collaboration
                                </h3>
                                {user ? (
                                    <VideoCall
                                        roomId={roomId}
                                        userId={user.uid}
                                        userName={user.displayName || "User"}
                                    />
                                ) : (
                                    <div className="text-center p-4 bg-gray-800 rounded-lg text-gray-400">
                                        Loading user data for call...
                                    </div>
                                )}
                            </div>
                        </div>
                    ) : (
                        <Whiteboard roomId={roomId} />
                    )}
                </div>
            </div>

            {/* Sidebar - Chat & Participants */}
            <div className="w-80 flex flex-col gap-4">
                <div className="flex-1 min-h-0">
                    <Chat roomId={roomId} />
                </div>
                <div className="h-1/3 min-h-0">
                    <ParticipantList roomId={roomId} />
                </div>
            </div>
        </div>
    );
}
