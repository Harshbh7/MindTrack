"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/context/AuthContext";
import { Users, Plus, ArrowRight, Play } from "lucide-react";
import { realtimeDb } from "@/lib/firebase";
import { ref, set, onValue, get } from "firebase/database";

interface Room {
    id: string;
    name: string;
    createdBy: string;
    createdAt: number;
}

export default function RoomLobbyPage() {
    const router = useRouter();
    const { user } = useAuth();
    const [roomId, setRoomId] = useState("");
    const [rooms, setRooms] = useState<Room[]>([]);
    const [loading, setLoading] = useState(true);
    const [selectedRoom, setSelectedRoom] = useState<Room | null>(null);
    const [inputCode, setInputCode] = useState("");
    const [error, setError] = useState("");
    const [joinError, setJoinError] = useState("");

    const [isCreating, setIsCreating] = useState(false);
    const [newRoomName, setNewRoomName] = useState("");

    // Fetch active rooms
    useEffect(() => {
        const roomsRef = ref(realtimeDb, 'rooms');
        const unsubscribe = onValue(roomsRef, (snapshot) => {
            const data = snapshot.val();
            const loadedRooms: Room[] = [];

            if (data) {
                Object.values(data).forEach((room: any) => {
                    loadedRooms.push({
                        id: room.id,
                        name: room.name,
                        createdBy: room.createdBy,
                        createdAt: room.createdAt
                    });
                });
                // Sort by newest first
                loadedRooms.sort((a, b) => b.createdAt - a.createdAt);
            }
            setRooms(loadedRooms);
            setLoading(false);
        });

        return () => unsubscribe();
    }, []);

    const handleCreateClick = () => {
        setIsCreating(true);
        setNewRoomName(`${user?.displayName || "User"}'s Group`);
    };

    const confirmCreateRoom = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!user || !newRoomName.trim()) return;

        // Generate simple 6-char ID
        const newRoomId = Math.random().toString(36).substring(2, 8).toUpperCase();

        // Save to DB
        try {
            await set(ref(realtimeDb, `rooms/${newRoomId}`), {
                id: newRoomId,
                name: newRoomName,
                createdBy: user.uid,
                createdAt: Date.now()
            });

            router.push(`/dashboard/room/${newRoomId}`);
        } catch (error) {
            console.error("Failed to create room:", error);
        }
    };

    const handleJoinRoom = async (e: React.FormEvent) => {
        e.preventDefault();
        setJoinError("");

        if (roomId.trim()) {
            const code = roomId.trim().toUpperCase();
            try {
                const snapshot = await get(ref(realtimeDb, `rooms/${code}`));
                if (snapshot.exists()) {
                    router.push(`/dashboard/room/${code}`);
                } else {
                    setJoinError("Invalid Room Code. Please check and try again.");
                }
            } catch (err) {
                console.error("Error validating room:", err);
                setJoinError("Error checking room code.");
            }
        }
    };

    const handleOpenClick = (room: Room) => {
        setSelectedRoom(room);
        setInputCode("");
        setError("");
    };

    const confirmJoin = (e: React.FormEvent) => {
        e.preventDefault();
        if (!selectedRoom) return;

        if (inputCode.trim().toUpperCase() === selectedRoom.id) {
            router.push(`/dashboard/room/${selectedRoom.id}`);
        } else {
            setError("Incorrect room code.");
        }
    };

    return (
        <div className="flex h-full flex-col p-6 space-y-8 relative">
            {/* Create Room Modal */}
            {isCreating && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
                    <div className="w-full max-w-md bg-gray-900 border border-gray-800 rounded-2xl p-6 shadow-2xl relative">
                        <button
                            onClick={() => setIsCreating(false)}
                            className="absolute top-4 right-4 text-gray-500 hover:text-white"
                        >
                            ✕
                        </button>

                        <h3 className="text-xl font-bold text-white mb-2">Name Your Group</h3>
                        <p className="text-sm text-gray-400 mb-6">Give your study group a cool name!</p>

                        <form onSubmit={confirmCreateRoom} className="space-y-4">
                            <div>
                                <input
                                    type="text"
                                    placeholder="e.g. Late Night Coders"
                                    className="w-full rounded-lg border border-gray-700 bg-gray-950 p-3 text-white placeholder-gray-500 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                                    value={newRoomName}
                                    onChange={(e) => setNewRoomName(e.target.value)}
                                    autoFocus
                                />
                            </div>

                            <button
                                type="submit"
                                className="w-full rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 transition-all"
                            >
                                Create & Join
                            </button>
                        </form>
                    </div>
                </div>
            )}

            {/* Modal Overlay */}
            {selectedRoom && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
                    <div className="w-full max-w-md bg-gray-900 border border-gray-800 rounded-2xl p-6 shadow-2xl relative">
                        <button
                            onClick={() => setSelectedRoom(null)}
                            className="absolute top-4 right-4 text-gray-500 hover:text-white"
                        >
                            ✕
                        </button>

                        <h3 className="text-xl font-bold text-white mb-2">Join {selectedRoom.name}</h3>
                        <p className="text-sm text-gray-400 mb-6">This room is protected. Please enter the room code to join.</p>

                        <form onSubmit={confirmJoin} className="space-y-4">
                            <div>
                                <input
                                    type="text"
                                    placeholder="Enter Room Code"
                                    className="w-full rounded-lg border border-gray-700 bg-gray-950 p-3 text-white placeholder-gray-500 focus:border-purple-500 focus:outline-none focus:ring-1 focus:ring-purple-500"
                                    value={inputCode}
                                    onChange={(e) => setInputCode(e.target.value)}
                                    autoFocus
                                />
                                {error && <p className="text-red-400 text-xs mt-2">{error}</p>}
                            </div>

                            <button
                                type="submit"
                                className="w-full rounded-lg bg-Purple-600 hover:bg-purple-700 bg-gradient-to-r from-purple-600 to-blue-600 text-white font-bold py-3 transition-all"
                            >
                                Verify & Join
                            </button>
                        </form>
                    </div>
                </div>
            )}

            <div className="text-center max-w-2xl mx-auto">
                <h1 className="text-4xl font-bold text-white mb-4">Study Rooms</h1>
                <p className="text-gray-400">Join a collaborative space to study with friends, share timers, and chat.</p>
            </div>

            {/* Actions Grid */}
            <div className="grid gap-6 md:grid-cols-2 max-w-4xl mx-auto w-full">
                {/* Create Room */}
                <div className="rounded-2xl border border-gray-800 bg-gray-900 p-6 transition-all hover:border-blue-500/50 hover:shadow-lg hover:shadow-blue-500/10">
                    <div className="flex items-center gap-4 mb-4">
                        <div className="p-3 rounded-lg bg-blue-500/10 text-blue-500">
                            <Plus className="h-6 w-6" />
                        </div>
                        <h2 className="text-xl font-bold text-white">Create New Room</h2>
                    </div>
                    <p className="mb-6 text-sm text-gray-400">Start a new study session and invite others to join you.</p>
                    <button
                        onClick={handleCreateClick}
                        className="w-full rounded-lg bg-blue-600 px-4 py-3 font-semibold text-white transition-all hover:bg-blue-500"
                    >
                        Create Room
                    </button>
                </div>

                {/* Join Room */}
                <div className="rounded-2xl border border-gray-800 bg-gray-900 p-6 transition-all hover:border-purple-500/50 hover:shadow-lg hover:shadow-purple-500/10">
                    <div className="flex items-center gap-4 mb-4">
                        <div className="p-3 rounded-lg bg-purple-500/10 text-purple-500">
                            <Users className="h-6 w-6" />
                        </div>
                        <h2 className="text-xl font-bold text-white">Join Room</h2>
                    </div>
                    <p className="mb-6 text-sm text-gray-400">Enter a room code to join an existing session.</p>
                    <form onSubmit={handleJoinRoom} className="flex gap-2">
                        <input
                            type="text"
                            placeholder="Enter Code"
                            className="flex-1 rounded-lg border border-gray-700 bg-gray-800 p-3 text-white placeholder-gray-500 focus:border-purple-500 focus:outline-none focus:ring-1 focus:ring-purple-500"
                            value={roomId}
                            onChange={(e) => setRoomId(e.target.value)}
                        />
                        <button
                            type="submit"
                            className="rounded-lg bg-purple-600 px-6 font-semibold text-white transition-all hover:bg-purple-500"
                        >
                            Join
                        </button>
                    </form>
                    {joinError && <p className="text-red-400 text-sm mt-3">{joinError}</p>}
                </div>
            </div>

            {/* Active Rooms List */}
            <div className="max-w-4xl mx-auto w-full">
                <h3 className="text-xl font-bold text-white mb-4">Active Rooms</h3>

                {loading ? (
                    <div className="text-center text-gray-500 py-10">Loading rooms...</div>
                ) : rooms.length === 0 ? (
                    <div className="text-center text-gray-500 py-10 bg-gray-900/50 rounded-xl border border-gray-800">
                        No active rooms. Create one to get started!
                    </div>
                ) : (
                    <div className="grid gap-4 md:grid-cols-2">
                        {rooms.map((room) => (
                            <div key={room.id} className="flex items-center justify-between p-4 rounded-xl bg-gray-900 border border-gray-800 hover:border-gray-700 transition-colors">
                                <div>
                                    <h4 className="font-semibold text-white">{room.name}</h4>
                                    <p className="text-xs text-gray-500 flex items-center gap-1">
                                        <Users className="h-3 w-3" /> Private Room
                                    </p>
                                </div>
                                <button
                                    onClick={() => handleOpenClick(room)}
                                    className="flex items-center px-4 py-2 bg-gray-800 hover:bg-gray-700 text-white rounded-lg text-sm font-medium transition-colors"
                                >
                                    Open <ArrowRight className="ml-2 h-4 w-4" />
                                </button>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
}
