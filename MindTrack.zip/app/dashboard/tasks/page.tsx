"use client";

import { useState, useEffect } from "react";
import { DragDropContext, Droppable, Draggable, DropResult } from "@hello-pangea/dnd";
import { Plus, Trash2, GripVertical, CheckCircle2 } from "lucide-react";

type Task = {
    id: string;
    content: string;
};

type Columns = {
    [key: string]: {
        name: string;
        items: Task[];
        color: string;
    };
};

const INITIAL_COLUMNS: Columns = {
    todo: {
        name: "To Do",
        items: [
            { id: "1", content: "Review Physics Notes" },
            { id: "2", content: "Complete Math Assignment" },
        ],
        color: "border-l-4 border-l-red-500",
    },
    inprogress: {
        name: "In Progress",
        items: [
            { id: "3", content: "React Project" },
        ],
        color: "border-l-4 border-l-yellow-500",
    },
    done: {
        name: "Done",
        items: [
            { id: "4", content: "Morning Meditation" },
        ],
        color: "border-l-4 border-l-green-500",
    },
};

export default function KanbanBoard() {
    const [columns, setColumns] = useState<Columns | null>(null);
    const [showInput, setShowInput] = useState<{ [key: string]: boolean }>({});
    const [newTask, setNewTask] = useState("");

    // Load from local storage
    useEffect(() => {
        const saved = localStorage.getItem("mindtrack-tasks");
        if (saved) {
            setColumns(JSON.parse(saved));
        } else {
            setColumns(INITIAL_COLUMNS);
        }
    }, []);

    // Save to local storage
    useEffect(() => {
        if (columns) {
            localStorage.setItem("mindtrack-tasks", JSON.stringify(columns));
        }
    }, [columns]);

    const onDragEnd = (result: DropResult) => {
        if (!result.destination || !columns) return;
        const { source, destination } = result;

        if (source.droppableId !== destination.droppableId) {
            const sourceColumn = columns[source.droppableId];
            const destColumn = columns[destination.droppableId];
            const sourceItems = [...sourceColumn.items];
            const destItems = [...destColumn.items];
            const [removed] = sourceItems.splice(source.index, 1);
            destItems.splice(destination.index, 0, removed);
            setColumns({
                ...columns,
                [source.droppableId]: { ...sourceColumn, items: sourceItems },
                [destination.droppableId]: { ...destColumn, items: destItems },
            });
        } else {
            const column = columns[source.droppableId];
            const copiedItems = [...column.items];
            const [removed] = copiedItems.splice(source.index, 1);
            copiedItems.splice(destination.index, 0, removed);
            setColumns({
                ...columns,
                [source.droppableId]: { ...column, items: copiedItems },
            });
        }
    };

    const addTask = (columnId: string) => {
        if (!newTask.trim() || !columns) return;
        const column = columns[columnId];
        const newItems = [...column.items, { id: Date.now().toString(), content: newTask }];
        setColumns({
            ...columns,
            [columnId]: { ...column, items: newItems },
        });
        setNewTask("");
        setShowInput({ ...showInput, [columnId]: false });
    };

    const deleteTask = (columnId: string, taskId: string) => {
        if (!columns) return;
        const column = columns[columnId];
        const newItems = column.items.filter((item) => item.id !== taskId);
        setColumns({
            ...columns,
            [columnId]: { ...column, items: newItems },
        });
    };

    if (!columns) return null; // Prevent hydration mismatch

    return (
        <div className="h-full flex flex-col gap-6">
            <h1 className="text-3xl font-bold text-white mb-2">My Tasks</h1>
            <div className="flex-1 overflow-x-auto overflow-y-hidden">
                <DragDropContext onDragEnd={onDragEnd}>
                    <div className="flex h-full gap-6 min-w-[1000px]">
                        {Object.entries(columns).map(([columnId, column]) => (
                            <div key={columnId} className="w-80 flex flex-col bg-gray-900 rounded-xl border border-gray-800 shadow-xl">
                                {/* Column Header */}
                                <div className={`p-4 font-bold text-lg text-white bg-gray-800/50 rounded-t-xl flex justify-between items-center ${column.color}`}>
                                    <h2>{column.name}</h2>
                                    <span className="text-sm bg-gray-700 px-2 py-0.5 rounded-full text-gray-300">
                                        {column.items.length}
                                    </span>
                                </div>

                                {/* Droppable Area */}
                                <Droppable droppableId={columnId}>
                                    {(provided, snapshot) => (
                                        <div
                                            {...provided.droppableProps}
                                            ref={provided.innerRef}
                                            className={`flex-1 p-3 flex flex-col gap-3 overflow-y-auto min-h-[150px] transition-colors ${snapshot.isDraggingOver ? "bg-gray-800/80" : ""
                                                }`}
                                        >
                                            {column.items.map((item, index) => (
                                                <Draggable key={item.id} draggableId={item.id} index={index}>
                                                    {(provided, snapshot) => (
                                                        <div
                                                            ref={provided.innerRef}
                                                            {...provided.draggableProps}
                                                            {...provided.dragHandleProps}
                                                            className={`p-3 bg-gray-800 rounded-lg shadow-sm border border-gray-700 group hover:border-gray-600 transition-all ${snapshot.isDragging ? "rotate-2 shadow-xl border-blue-500 bg-gray-750" : ""
                                                                }`}
                                                            style={provided.draggableProps.style}
                                                        >
                                                            <div className="flex justify-between items-start gap-2">
                                                                <p className="text-gray-200 text-sm leading-relaxed">{item.content}</p>
                                                                <button
                                                                    onClick={() => deleteTask(columnId, item.id)}
                                                                    className="opacity-0 group-hover:opacity-100 text-gray-500 hover:text-red-400 transition-opacity"
                                                                >
                                                                    <Trash2 className="w-4 h-4" />
                                                                </button>
                                                            </div>
                                                        </div>
                                                    )}
                                                </Draggable>
                                            ))}
                                            {provided.placeholder}

                                            {/* Add Task Input */}
                                            {showInput[columnId] ? (
                                                <div className="p-2 bg-gray-800 border border-gray-600 rounded-lg animate-in fade-in zoom-in-95 duration-200">
                                                    <textarea
                                                        autoFocus
                                                        value={newTask}
                                                        onChange={(e) => setNewTask(e.target.value)}
                                                        placeholder="Enter task..."
                                                        className="w-full bg-transparent text-sm text-white resize-none focus:outline-none mb-2"
                                                        rows={2}
                                                        onKeyDown={(e) => {
                                                            if (e.key === 'Enter' && !e.shiftKey) {
                                                                e.preventDefault();
                                                                addTask(columnId);
                                                            }
                                                        }}
                                                    />
                                                    <div className="flex gap-2 justify-end">
                                                        <button
                                                            onClick={() => setShowInput({ ...showInput, [columnId]: false })}
                                                            className="text-xs text-gray-400 hover:text-white"
                                                        >
                                                            Cancel
                                                        </button>
                                                        <button
                                                            onClick={() => addTask(columnId)}
                                                            className="px-3 py-1 bg-blue-600 hover:bg-blue-500 rounded text-xs text-white font-medium"
                                                        >
                                                            Add
                                                        </button>
                                                    </div>
                                                </div>
                                            ) : (
                                                <button
                                                    onClick={() => setShowInput({ ...showInput, [columnId]: true })}
                                                    className="flex items-center gap-2 text-gray-400 hover:text-white hover:bg-gray-800 p-2 rounded-lg transition-colors text-sm font-medium"
                                                >
                                                    <Plus className="w-4 h-4" />
                                                    Add Task
                                                </button>
                                            )}
                                        </div>
                                    )}
                                </Droppable>
                            </div>
                        ))}
                    </div>
                </DragDropContext>
            </div>
        </div>
    );
}
