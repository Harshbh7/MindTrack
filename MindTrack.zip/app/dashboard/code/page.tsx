import CodeEditor from "@/components/CodeEditor";

export default function CodePage() {
    return (
        <div className="flex h-[calc(100vh-6rem)] flex-col gap-4">
            <div className="mb-2">
                <h1 className="text-2xl font-bold text-white">Coding Arena</h1>
                <p className="text-gray-400">Practice algorithms and solve problems in real-time.</p>
            </div>
            <CodeEditor />
        </div>
    );
}
