import { NextResponse } from 'next/server';
import OpenAI from 'openai';

export async function POST(req: Request) {
    try {
        const apiKey = process.env.OPENAI_API_KEY;

        if (!apiKey) {
            // This allows the build to pass if the key isn't present, 
            // but will fail at runtime if not set.
            console.warn("OPENAI_API_KEY is not set");
            return NextResponse.json({
                error: 'OpenAI API Key is not configured. Please add it to .env.local'
            }, { status: 500 });
        }

        // Instantiate only when we have a key and a request
        const openai = new OpenAI({
            apiKey: apiKey,
        });

        const { messages } = await req.json();

        if (!messages) {
            return NextResponse.json({ error: 'Messages are required' }, { status: 400 });
        }

        const completion = await openai.chat.completions.create({
            model: "gpt-3.5-turbo",
            messages: [
                { role: "system", content: "You are an AI Tutor for MindTrack. You help students with their studies, explain concepts, and solve coding doubts. Be encouraging and concise." },
                ...messages
            ],
        });

        const reply = completion.choices[0].message.content;

        return NextResponse.json({ reply });
    } catch (error: any) {
        console.error('OpenAI API Error:', error);
        return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
    }
}
