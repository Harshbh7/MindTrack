"use client";

import { useEffect, useState } from "react";
import { Tldraw, useEditor, Editor } from "@tldraw/tldraw";
import "@tldraw/tldraw/tldraw.css";
import { useSocket } from "@/hooks/useSocket";

// Wrapper to access the editor context
function WhiteboardEditor({ roomId }: { roomId: string }) {
    const editor = useEditor();
    const { socket } = useSocket();
    const [isRemoteUpdate, setIsRemoteUpdate] = useState(false);

    useEffect(() => {
        if (!editor || !socket) return;

        // 0. Join Room (Just in case, though Chat/Video joins too)
        socket.emit("join-room", roomId, "whiteboard-user");

        // 1. Listen for local changes and broadcast
        const cleanupListener = editor.store.listen((update) => {
            // Only broadcast if the change didn't come from a remote source
            // Tldraw updates have 'source' ('user' or 'remote')
            // But here 'update' object structure is { changes: ... }
            if (isRemoteUpdate) return;

            // Filter specific changes (added, updated, removed)
            // For simplicity in this demo, we broadcast the standard update object
            // Ideally we filter out selection changes to avoid jitter

            const changes = update.changes;
            // Basic filtering could be done here
            console.log("[Whiteboard] Broadcasting local change:", changes);

            socket.emit("whiteboard-draw", { roomId, data: changes });
        }, { source: 'user', scope: 'document' }); // Listen to user document changes

        // 2. Listen for remote changes
        socket.on("whiteboard-update", (changes: any) => {
            console.log("[Whiteboard] Received remote update:", changes);
            setIsRemoteUpdate(true);
            try {
                const { added, updated, removed } = changes;

                editor.store.mergeRemoteChanges(() => {
                    if (added) {
                        Object.values(added).forEach((record: any) => {
                            editor.store.put([record]);
                        });
                    }
                    if (updated) {
                        Object.values(updated).forEach((record: any) => {
                            // Robust check: Is it [from, to] diff or just the new record?
                            if (Array.isArray(record) && record.length === 2 && record[1].id) {
                                // It is a history entry [from, to]
                                editor.store.put([record[1]]);
                            } else {
                                // Assume it is the record itself
                                editor.store.put([record]);
                            }
                        });
                    }
                    if (removed) {
                        Object.values(removed).forEach((record: any) => {
                            editor.store.remove([record.id]);
                        });
                    }
                });
            } catch (e) {
                console.error("Sync error", e);
            } finally {
                setIsRemoteUpdate(false);
            }
        });

        // 3. State Recovery: New User -> Request -> Old User -> Replies
        socket.emit("request-canvas-state", { roomId });

        // If someone asks for state, send it (if we have data)
        socket.on("client-request-canvas-state", ({ requesterId }: { requesterId: string }) => {
            const snapshot = editor.store.getSnapshot();
            // Simple logic: If I have more than 0 shapes, I reply.
            // A more robust way: minimal delay to avoid flooding, or leader election.
            // For now: Everyone sends. The receiver handles the first one.
            if (Object.keys(snapshot.store).length > 0) {
                socket.emit("send-canvas-state", { roomId, state: snapshot, requesterId });
            }
        });

        // Receive state
        socket.on("canvas-state-response", (snapshot: any) => {
            setIsRemoteUpdate(true);
            try {
                editor.store.loadSnapshot(snapshot);
            } catch (e) {
                console.error("Failed to load snapshot", e);
            } finally {
                setIsRemoteUpdate(false);
            }
        });

        return () => {
            cleanupListener();
            socket.off("whiteboard-update");
            socket.off("client-request-canvas-state");
            socket.off("canvas-state-response");
        };
    }, [editor, socket, roomId]);

    return null; // Logic only
}

export default function Whiteboard({ roomId }: { roomId?: string }) {
    // If no roomId (e.g. testing), just render local
    if (!roomId) roomId = "demo-room";

    return (
        <div className="w-full h-full relative rounded-xl overflow-hidden border border-gray-800 bg-gray-900">
            <Tldraw persistenceKey={`room-${roomId}`}>
                <WhiteboardEditor roomId={roomId} />
            </Tldraw>
        </div>
    );
}
