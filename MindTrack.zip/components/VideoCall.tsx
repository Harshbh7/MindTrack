import { useEffect, useRef, useState } from "react";
import Peer from "simple-peer";
import { Phone, PhoneOff, Video, VideoOff, Mic, MicOff } from "lucide-react";
import { useSocket } from "@/hooks/useSocket";

interface VideoCallProps {
    roomId: string;
    userId: string;
    userName: string;
}

export default function VideoCall({ roomId, userId, userName }: VideoCallProps) {
    const { socket, isConnected } = useSocket();

    // Call State
    const [stream, setStream] = useState<MediaStream | null>(null);
    const [receivingCall, setReceivingCall] = useState(false);
    const [caller, setCaller] = useState("");
    const [callerName, setCallerName] = useState("");
    const [callerSignal, setCallerSignal] = useState<any>();
    const [callAccepted, setCallAccepted] = useState(false);
    const [callEnded, setCallEnded] = useState(false);
    const [isCalling, setIsCalling] = useState(false);

    // Media & Type State
    const [callType, setCallType] = useState<"video" | "audio">("video");
    const [remoteCallType, setRemoteCallType] = useState<"video" | "audio">("video"); // What the caller initiated
    const [micOn, setMicOn] = useState(true);
    const [videoOn, setVideoOn] = useState(true);

    const myVideo = useRef<HTMLVideoElement>(null);
    const userVideo = useRef<HTMLVideoElement>(null);
    const connectionRef = useRef<Peer.Instance | null>(null);

    useEffect(() => {
        // Initialize socket listeners
        if (socket && isConnected) {
            socket.emit("join-room", roomId, userId);

            socket.on("incoming-call", (data: any) => {
                if (data.from !== userId) {
                    setReceivingCall(true);
                    setCaller(data.from);
                    setCallerName(data.name);
                    setCallerSignal(data.signal);
                    setRemoteCallType(data.callType || "video"); // Get call type from signal
                }
            });

            socket.on("call-ended", () => {
                // Determine if we need to clean up
                // If we are in a call, end it.
                // If receiving call, cancel it.
                setCallEnded(true);
                if (connectionRef.current) {
                    connectionRef.current.destroy();
                }
                // Optional: stop my stream if I want to auto-clean up?
                // Probably yes.
                if (stream) {
                    stream.getTracks().forEach(track => track.stop());
                    setStream(null);
                }
                setReceivingCall(false);
                setCaller("");
                setCallerName("");
                setCallerSignal(null);
                setCallAccepted(false);
                setIsCalling(false);
                setMicOn(true);
                setVideoOn(true);
            });
        }
    }, [socket, isConnected, roomId, userId, stream]);

    const getMedia = async (type: "video" | "audio") => {
        try {
            const constraints = {
                video: type === "video",
                audio: true,
            };
            const currentStream = await navigator.mediaDevices.getUserMedia(constraints);
            setStream(currentStream);

            // Only attach to video element if video is present
            if (type === "video" && myVideo.current) {
                myVideo.current.srcObject = currentStream;
            }
            return currentStream;
        } catch (err) {
            console.error("Error accessing media devices:", err);
            alert("Could not access camera/microphone");
            return null;
        }
    };

    const callUser = async (type: "video" | "audio") => {
        setIsCalling(true);
        setCallType(type);
        setCallEnded(false);

        const currentStream = await getMedia(type);
        if (!currentStream) {
            setIsCalling(false);
            return;
        }

        const peer = new Peer({
            initiator: true,
            trickle: false,
            stream: currentStream,
        });

        peer.on("signal", (data) => {
            socket.emit("initiate-call", {
                roomId,
                signalData: data,
                fromUserId: userId,
                fromUserName: userName,
                callType: type, // Send call type
            });
        });

        peer.on("stream", (remoteStream) => {
            if (userVideo.current) {
                userVideo.current.srcObject = remoteStream;
            }
        });

        peer.on("close", () => {
            // peer closed
            leaveCall();
        });

        peer.on("error", (err) => {
            console.error("Peer error:", err);
            leaveCall();
        });

        socket.on("call-accepted", (data: any) => {
            setCallAccepted(true);
            peer.signal(data.signal);
        });

        connectionRef.current = peer;
    };

    const answerCall = async () => {
        setCallAccepted(true);
        setCallType(remoteCallType); // Answer with same type (usually)
        setCallEnded(false);

        const currentStream = await getMedia(remoteCallType);
        if (!currentStream) return;

        const peer = new Peer({
            initiator: false,
            trickle: false,
            stream: currentStream,
        });

        peer.on("signal", (data) => {
            socket.emit("answer-call", {
                roomId,
                signal: data,
                toUserId: caller
            });
        });

        peer.on("stream", (remoteStream) => {
            if (userVideo.current) {
                userVideo.current.srcObject = remoteStream;
            }
        });

        peer.on("close", () => {
            // peer closed
            leaveCall();
        });

        peer.on("error", (err) => {
            console.error("Peer error:", err);
            leaveCall();
        });

        peer.signal(callerSignal);
        connectionRef.current = peer;
    };

    const leaveCall = () => {
        setCallEnded(true);

        // Notify others
        if (socket) {
            socket.emit("leave-call", { roomId });
        }

        if (connectionRef.current) {
            connectionRef.current.destroy();
        }
        if (stream) {
            stream.getTracks().forEach(track => track.stop());
            setStream(null);
        }

        // Reset states
        setReceivingCall(false);
        setCaller("");
        setCallerName("");
        setCallerSignal(null);
        setCallAccepted(false);
        setIsCalling(false);
        setMicOn(true);
        setVideoOn(true);
    };

    const toggleMic = () => {
        if (stream) {
            const audioTrack = stream.getAudioTracks()[0];
            if (audioTrack) {
                audioTrack.enabled = !micOn;
                setMicOn(!micOn);
            }
        }
    }

    const toggleVideo = () => {
        if (stream && callType === 'video') {
            const videoTrack = stream.getVideoTracks()[0];
            if (videoTrack) {
                videoTrack.enabled = !videoOn;
                setVideoOn(!videoOn);
            }
        }
    }

    return (
        <div className="flex flex-col items-center justify-center p-4 bg-gray-900 rounded-xl mb-4 border border-gray-800 max-h-[600px] overflow-y-auto">
            {/* Call Controls (Start Call) */}
            {!callAccepted && !receivingCall && !isCalling && (
                <div className="flex space-x-4">
                    <button
                        onClick={() => callUser("audio")}
                        disabled={!isConnected}
                        className="flex items-center space-x-2 px-4 py-2 bg-green-600 hover:bg-green-700 rounded-lg text-white font-semibold transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        <Phone className="w-5 h-5" />
                        <span>Voice Call</span>
                    </button>
                    <button
                        onClick={() => callUser("video")}
                        disabled={!isConnected}
                        className="flex items-center space-x-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg text-white font-semibold transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        <Video className="w-5 h-5" />
                        <span>Video Call</span>
                    </button>
                </div>
            )}

            {/* Incoming Call Notification */}
            {receivingCall && !callAccepted && (
                <div className="flex flex-col items-center bg-gray-800 p-4 rounded-lg animate-pulse border border-blue-500">
                    <h3 className="text-white text-lg font-bold mb-2">
                        {callerName} is requesting a {remoteCallType} call...
                    </h3>
                    <div className="flex space-x-4">
                        <button
                            onClick={answerCall}
                            className="bg-green-500 hover:bg-green-600 p-3 rounded-full text-white transition-transform hover:scale-110"
                        >
                            <Phone className="w-6 h-6" />
                        </button>
                        <button
                            onClick={leaveCall}
                            className="bg-red-500 hover:bg-red-600 p-3 rounded-full text-white transition-transform hover:scale-110"
                        >
                            <PhoneOff className="w-6 h-6" />
                        </button>
                    </div>
                </div>
            )}

            {/* Call Area */}
            {(callAccepted || isCalling) && !callEnded && (
                <div className="w-full flex flex-col space-y-4">
                    {/* Media Display */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 w-full">
                        {/* My Media */}
                        <div className="relative bg-black rounded-lg overflow-hidden h-48 md:h-60 w-full flex items-center justify-center">
                            {callType === 'video' && stream ? (
                                <video
                                    playsInline
                                    muted
                                    ref={myVideo}
                                    autoPlay
                                    className="w-full h-full object-cover transform scale-x-[-1]"
                                />
                            ) : (
                                <div className="text-gray-400 flex flex-col items-center">
                                    <div className="bg-gray-700 p-4 rounded-full mb-2">
                                        <Mic className="w-8 h-8" />
                                    </div>
                                    <span>You (Audio)</span>
                                </div>
                            )}
                            <div className="absolute bottom-2 left-2 bg-black/50 px-2 py-1 rounded text-white text-xs">You</div>
                        </div>

                        {/* Remote Media */}
                        {callAccepted && (
                            <div className="relative bg-black rounded-lg overflow-hidden h-48 md:h-60 w-full flex items-center justify-center">
                                {(remoteCallType === 'video' || (callType === 'video')) ? (
                                    <video
                                        playsInline
                                        ref={userVideo}
                                        autoPlay
                                        className="w-full h-full object-cover"
                                    />
                                ) : (
                                    <div className="text-gray-400 flex flex-col items-center">
                                        <div className="bg-gray-700 p-4 rounded-full mb-2">
                                            <Mic className="w-8 h-8" />
                                        </div>
                                        <span>{callerName || "Remote User"}</span>
                                    </div>
                                )}
                                <div className="absolute bottom-2 left-2 bg-black/50 px-2 py-1 rounded text-white text-xs">{callerName || "Remote User"}</div>
                            </div>
                        )}
                    </div>

                    {/* In-Call Controls */}
                    <div className="flex justify-center space-x-4 mt-4">
                        <button onClick={toggleMic} className={`p-3 rounded-full text-white ${micOn ? 'bg-gray-700 hover:bg-gray-600' : 'bg-red-500 hover:bg-red-600'}`}>
                            {micOn ? <Mic className="w-5 h-5" /> : <MicOff className="w-5 h-5" />}
                        </button>

                        {callType === 'video' && (
                            <button onClick={toggleVideo} className={`p-3 rounded-full text-white ${videoOn ? 'bg-gray-700 hover:bg-gray-600' : 'bg-red-500 hover:bg-red-600'}`}>
                                {videoOn ? <Video className="w-5 h-5" /> : <VideoOff className="w-5 h-5" />}
                            </button>
                        )}

                        <button
                            onClick={leaveCall}
                            className="bg-red-600 hover:bg-red-700 p-3 rounded-full text-white transition-colors"
                        >
                            <PhoneOff className="w-5 h-5" />
                        </button>
                    </div>
                </div>
            )}

            {/* Status Messages */}
            {isCalling && !callAccepted && (
                <div className="mt-4 text-blue-400 animate-pulse">Calling... waiting for answer</div>
            )}
            {!isConnected && (
                <div className="mt-2 text-xs text-red-500">Connection to call server failed</div>
            )}
        </div>
    );
}
