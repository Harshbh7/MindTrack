"use client";

import { useState } from "react";
import Editor from "@monaco-editor/react";
import { Play, Code as CodeIcon, RotateCw, Bot, CheckCircle } from "lucide-react";

export default function CodeEditor() {
    const [language, setLanguage] = useState("javascript");
    const [code, setCode] = useState("// Write your code here\nconsole.log('Hello, MindTrack!');");
    const [output, setOutput] = useState("");
    const [isRunning, setIsRunning] = useState(false);

    // AI State
    const [isReviewing, setIsReviewing] = useState(false);
    const [aiSuggestion, setAiSuggestion] = useState("");

    const handleRunCode = async () => {
        setIsRunning(true);
        setOutput("Running...");

        // Simulate execution or call API
        setTimeout(() => {
            try {
                // Very unsafe eval for demo purposes only in JS
                // In production, send to backend API
                if (language === "javascript") {
                    let logs: string[] = [];
                    const originalLog = console.log;
                    console.log = (...args) => logs.push(args.join(" "));

                    try {
                        // eslint-disable-next-line no-eval
                        eval(code);
                    } catch (e: any) {
                        logs.push("Error: " + e.message);
                    }

                    console.log = originalLog;
                    setOutput(logs.join("\n") || "No output");
                } else {
                    setOutput(`Execution for ${language} requires backend service connection.`);
                }
            } catch (err: any) {
                setOutput("Error: " + err.message);
            }
            setIsRunning(false);
        }, 1000);
    };

    const handleAiReview = async () => {
        setIsReviewing(true);
        setAiSuggestion("");

        try {
            const res = await fetch('/api/ai/review', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ code, language })
            });
            const data = await res.json();
            setAiSuggestion(data.suggestion);
        } catch (err) {
            setAiSuggestion("Failed to get AI review. Please try again.");
        } finally {
            setIsReviewing(false);
        }
    };

    return (
        <div className="flex h-full flex-col gap-4">
            {/* Editor Controls */}
            <div className="flex items-center justify-between rounded-xl border border-gray-800 bg-gray-900 p-4">
                <div className="flex items-center space-x-4">
                    <CodeIcon className="h-6 w-6 text-blue-400" />
                    <select
                        value={language}
                        onChange={(e) => setLanguage(e.target.value)}
                        className="rounded-lg border border-gray-700 bg-gray-800 p-2 text-white focus:outline-none focus:ring-1 focus:ring-blue-500"
                    >
                        <option value="javascript">JavaScript</option>
                        <option value="python">Python</option>
                        <option value="cpp">C++</option>
                        <option value="java">Java</option>
                        <option value="html">HTML</option>
                    </select>
                </div>
                <div className="flex items-center space-x-2">
                    <button
                        onClick={handleAiReview}
                        disabled={isReviewing}
                        className="flex items-center space-x-2 rounded-lg bg-pink-600/20 px-4 py-2 text-sm font-semibold text-pink-400 hover:bg-pink-600/30 transition-colors disabled:opacity-50"
                    >
                        {isReviewing ? (
                            <div className="h-4 w-4 animate-spin rounded-full border-2 border-pink-400 border-t-transparent"></div>
                        ) : (
                            <Bot className="h-4 w-4" />
                        )}
                        <span>{isReviewing ? "Analyzing..." : "AI Review"}</span>
                    </button>

                    <button
                        onClick={() => setCode("")}
                        className="rounded-lg p-2 text-gray-400 hover:bg-gray-800 hover:text-white"
                    >
                        <RotateCw className="h-5 w-5" />
                    </button>
                    <button
                        onClick={handleRunCode}
                        disabled={isRunning}
                        className="flex items-center space-x-2 rounded-lg bg-green-600 px-4 py-2 font-semibold text-white hover:bg-green-500 disabled:opacity-50"
                    >
                        <Play className="h-4 w-4" />
                        <span>{isRunning ? "Running..." : "Run Code"}</span>
                    </button>
                </div>
            </div>

            <div className="grid flex-1 gap-4 lg:grid-cols-2">
                {/* Editor Area */}
                <div className="overflow-hidden rounded-xl border border-gray-800 bg-[#1e1e1e] relative">
                    <Editor
                        height="100%"
                        defaultLanguage="javascript"
                        language={language}
                        value={code}
                        theme="vs-dark"
                        onChange={(value) => setCode(value || "")}
                        options={{
                            minimap: { enabled: false },
                            fontSize: 14,
                            scrollBeyondLastLine: false,
                            automaticLayout: true,
                        }}
                    />

                    {/* AI Feedback Overlay (if any) */}
                    {aiSuggestion && (
                        <div className="absolute bottom-4 right-4 max-w-sm bg-gray-900/95 backdrop-blur-sm border border-pink-500/50 rounded-xl p-4 shadow-2xl animate-in slide-in-from-bottom-2">
                            <div className="flex items-start justify-between mb-2">
                                <div className="flex items-center gap-2 text-pink-400 font-bold">
                                    <Bot className="h-4 w-4" />
                                    <span>AI Feedback</span>
                                </div>
                                <button onClick={() => setAiSuggestion("")} className="text-gray-500 hover:text-white">✕</button>
                            </div>
                            <p className="text-sm text-gray-200 leading-relaxed">{aiSuggestion}</p>
                        </div>
                    )}
                </div>

                {/* Output Area */}
                <div className="flex flex-col rounded-xl border border-gray-800 bg-gray-900">
                    <div className="border-b border-gray-800 p-3">
                        <h3 className="text-sm font-semibold text-gray-400">Console Output</h3>
                    </div>
                    <div className="flex-1 overflow-auto p-4 font-mono text-sm text-gray-300 whitespace-pre-wrap">
                        {output || <span className="text-gray-600">Run code to see output...</span>}
                    </div>
                </div>
            </div>
        </div>
    );
}
