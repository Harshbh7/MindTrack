import { useEffect, useState } from "react";
import { io as ClientIO } from "socket.io-client";

export const useSocket = () => {
    const [socket, setSocket] = useState<any>(null);
    const [isConnected, setIsConnected] = useState(false);

    useEffect(() => {
        const socketInitializer = async () => {
            // We call the API route to ensure the server is set up
            await fetch("/api/socket/io");

            const socketInstance = ClientIO(process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000", {
                path: "/api/socket/io",
                addTrailingSlash: false,
            });

            socketInstance.on("connect", () => {
                console.log("Socket connected from hook");
                setIsConnected(true);
            });

            socketInstance.on("disconnect", () => {
                console.log("Socket disconnected");
                setIsConnected(false);
            });

            socketInstance.on("connect_error", (err) => {
                console.log(`connect_error due to ${err.message}`);
            });

            setSocket(socketInstance);
        };

        socketInitializer();

        return () => {
            // Cleanup would require knowing if we should disconnect global socket
            // For now, we leave it or relying on component unmount to not leak listeners
            // But usually we want to disconnect if the hook unmounts? 
            // In a global provider context, we wouldn't. 
            // Since this hook is called in components, let's keep it simple.
            // If we disconnect here, navigating away breaks the socket for others?
            // No, just this client.
            if (socket) {
                // socket.disconnect(); 
                // Don't disconnect here immediately if we want persistence across re-renders in dev
                // But generally clean up is good.
                // However, the `socket` state variable is local here. 
                // The cleanup function captures closure variables. 
                // Let's iterate: The previous code disconnected. 
                // But since we are doing async init, we need to be careful with race conditions.
            }
        };
    }, []);

    // Better cleanup logic
    useEffect(() => {
        return () => {
            if (socket) {
                socket.disconnect();
            }
        }
    }, [socket]);

    return { socket, isConnected };
};
